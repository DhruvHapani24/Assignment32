/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Fall, 2023
* Author: TO_DO
* Professors: Paulo Sousa
************************************************************
=---------------------------------------=
|  COMPILERS - ALGONQUIN COLLEGE (F23)  |
=---------------------------------------=
|              ....                     |
|          ........::.::::::.           |
|        .:........::.:^^^~~~:          |
|        :^^::::::^^^::^!7??7~^.        |
|       .:^~~^!77777~~7?YY?7??7^.       |
|       :.^~!??!^::::^^~!?5PY??!~.      |
|       ~!!7J~.:::^^^^~!!~~?G5J?~       |
|       :^~?!~7?Y57^^?PP5YJ!J5Y?:       |
|       .~!!.:^!7!:.:7JYYJ7~7Y7^        |
|       .~77..    . .~^:^^^~7?:         |
|       .^!^~:::.:^!7?~^~!77J:          |
|        ^^!Y~^^^^~?YJ77??7JJ^          |
|       .^7J?~^~~^~7??7??7JY?~:         |
|        ::^^~^7?!^~~!7???J?J7~:.       |
|         ^~~!.^7YPPPP5Y?7J7777~.       |
|        ..:~..:^!JPP5YJ?!777!^.        |
| .~?JJJJJJJJJJYYYYYPPPPPPPPPPPP5PPYY~  |
|  :!Y5GGG.___ YYYYYY__._.PPGGGGGG5!.   |
|   :!Y5G / __| ___ / _(_)__ _ PGP5.    |
|    :~75 \__ \/ _ \  _| / _` | 5?.     |
|     7~7 |___/\___/_| |_\__,_| Y5?.    |
|    .^~!~.....................P5YY7.   |
|   .:::::::::::::?JJJJYYYYYYYYYJJJJ7.  |
|                                       |
=---------------------------------------=
*/

/*
************************************************************
* File name: Scanner.h
* Compiler: MS Visual Studio 2022
* Course: CST 8152 � Compilers, Lab Section: [011, 012]
* Assignment: A22, A32.
* Date: May 01 2022
* Purpose: This file is the main header for Scanner (.h)
* Function list: (...).
*************************************************************/

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef READER_H_
#include "Reader.h"
#endif

#ifndef SCANNER_H_
#define SCANNER_H_

#ifndef NULL
#include <_null.h> /* NULL pointer constant is defined there */
#endif

/*#pragma warning(1:4001) */	/*to enforce C89 type comments  - to make //comments an warning */

/*#pragma warning(error:4001)*/	/* to enforce C89 comments - to make // comments an error */

/* Constants */
#define VID_LEN 20  /* variable identifier length */
#define ERR_LEN 40  /* error message length */
#define NUM_LEN 5   /* maximum number of digits for IL */

#define RTE_CODE 1  /* Value for run-time error */

/* TO_DO: Define the number of tokens */
#define NUM_TOKENS 18

/* TO_DO: Define Token codes - Create your token classes */
enum TOKENS {
	ERR_T,      /*  0: Error token */
	MNID_T,     /*  1: Method name identifier token (start: &) */
	INL_T,      /*  2: Integer literal token */
	STR_T,      /*  3: String literal token */
	LPR_T,      /*  4: Left parenthesis token */
	RPR_T,      /*  5: Right parenthesis token */
	LBR_T,      /*  6: Left brace token */
	RBR_T,      /*  7: Right brace token */
	KW_T,       /*  8: Keyword token */
	EOS_T,      /*  9: End of statement (semicolon) */
	RTE_T,      /* 10: Run-time error token */
	SEOF_T,     /* 11: Source end-of-file token */
	CMT_T,      /* 12: Comment token */
	D_T,        /* 13: Digits token */
	U_T,        /* 14: Underscore token */
	O_T,        /* 15: Other characters token */
	FLOAT_T,    /* 16: Floating point token */
	M_T        /* 17: Method identifier token */
};

/* TO_DO: Define the list of keywords */
static char* tokenStrTable[NUM_TOKENS] = {
	"ERR_T",
	"MNID_T",
	"INL_T",
	"STR_T",
	"LPR_T",
	"RPR_T",
	"LBR_T",
	"RBR_T",
	"KW_T",
	"EOS_T",
	"RTE_T",
	"SEOF_T",
	"CMT_T",
	"D_T",
	"U_T",
	"O_T",
	"FLOAT_T",
	"M_T"
};

/* TO_DO: Operators token attributes */
typedef enum ArithmeticOperators { OP_ADD, OP_SUB, OP_MUL, OP_DIV } AriOperator;
typedef enum RelationalOperators { OP_EQ, OP_NE, OP_GT, OP_LT } RelOperator;
typedef enum LogicalOperators { OP_AND, OP_OR, OP_NOT } LogOperator;
typedef enum SourceEndOfFile { SEOF_0, SEOF_255 } EofOperator;

/* TO_DO: Data structures for declaring the token and its attributes */
typedef union TokenAttribute {
	uint codeType;      /* integer attributes accessor */
	AriOperator arithmeticOperator;		/* arithmetic operator attribute code */
	RelOperator relationalOperator;		/* relational operator attribute code */
	LogOperator logicalOperator;		/* logical operator attribute code */
	EofOperator seofType;				/* source-end-of-file attribute code */
	uint intValue;				/* integer literal attribute (value) */
	uint keywordIndex;			/* keyword index in the keyword table */
	uint contentString;			/* string literal offset from the beginning of the string literal buffer (stringLiteralTable->content) */
	float32 floatValue;				/* floating-point literal attribute (value) */
	rune idLexeme[VID_LEN + 1];	/* variable identifier token attribute */
	rune errLexeme[ERR_LEN + 1];	/* error token attribite */
} TokenAttribute;

/* TO_DO: Should be used if no symbol table is implemented */
typedef struct idAttibutes {
	byte flags;			/* Flags information */
	union {
		uint intValue;				/* Integer value */
		float32 floatValue;			/* Float value */
		string stringContent;		/* String value */
	} values;
} IdAttibutes;

/* Token declaration */
typedef struct Token {
	uint code;				/* token code */
	TokenAttribute attribute;	/* token attribute */
	IdAttibutes   idAttribute;	/* not used in this scanner implementation - for further use */
} Token;

/* Scanner */
typedef struct scannerData {
	uint scanHistogram[NUM_TOKENS];	/* Statistics of chars */
} ScannerData, * pScanData;

///////////////////////////////////////////////////////////////////////////////////////////////////////

/* EOF definitions */
#define CHARSEOF0 '\0'
#define CHARSEOF255 0xFF

/*  Special case tokens processed separately one by one in the token-driven part of the scanner:
 *  LPR_T, RPR_T, LBR_T, RBR_T, EOS_T, SEOF_T and special chars used for tokenis include _, & and ' */

 /* TO_DO: Define lexeme FIXED classes */
 /* These constants will be used on nextClass */
#define CHRCOL3 '//'
#define CHRCOL4 '/*'
#define CHRCOL6 '*/'
#define CHRCOL7 '"'
#define CHRCOL8 '.'
#define CHRCOL2 '_'
#define CHRCOL5 '&'



/* These constants will be used on VID / MID function */
#define MNID_SUF '&'
#define COMM_SYM '#'

/* TO_DO: Error states and illegal state */
#define ESNR	20		/* Error state with no retract */
#define ESWR	30		/* Error state with retract */
#define FS		40		/* Illegal state */

 /* TO_DO: State transition table definition */
#define NUM_STATES		14
#define CHAR_CLASSES	13

/* TO_DO: Transition table - type of states defined in separate table */
static uint transitionTable[NUM_STATES][CHAR_CLASSES] = {
	/*         [A-z]  [0-9]  _      //    /*    &     *///   "     O		k		T	  .   */
	/* S0  */ {   4,     6,  ESNR,   1,    3,  ESNR,  ESNR,  10,  ESNR,    12,       13,  ESNR,		FS}, // NOAS
	/* S1  */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,    1,     FS,       FS,    FS,		FS}, // NOAS
	/* S2  */ {ESNR,  ESNR, ESNR, ESNR, ESNR, ESNR,    3,  ESNR,    2,   ESNR,     ESNR,  ESNR,		ESNR}, // ASNR (MVID)
	/* S3  */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,   FS,     FS,       FS,    FS,		FS}, // ASWR (KEY)
	/* S4  */ {   4,     4,    4, ESNR, ESNR,    5,  ESNR, ESNR,    3,   ESNR,     ESNR,  ESNR,	ESNR}, // NOAS
	/* S5  */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,   FS,     FS,       FS,    FS,		ESNR}, // ASNR (SL)
	/* S6  */ {   7,     6,    7,    7,    7,    7,  7,       7,     7,     7,        7,     7,	    7}, // NOAS
	/* S7  */ {ESNR,     7, ESNR, ESNR, ESNR, ESNR,  ESNR, ESNR,  ESNR,   ESNR,     ESNR,     8,	ESNR}, // ASNR (COM)
	/* S8  */ {ESNR,     9, ESNR, ESNR, ESNR, ESNR,  ESNR, ESNR,  ESNR,   ESNR,     ESNR,  ESNR,	ESNR}, // ASNR (ES)
	/* S9  */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,   FS,     FS,       FS,    FS,		FS}, // ASWR (ER)
	/* S10 */ {  10,    10,   10,   10,   10,   10,    10,   11,   10,     10,       10,    10,		FS}, // ASWR (ER)
	/* S11 */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,   FS,     FS,       FS,    FS,		FS}, // ASWR (ER)
	/* S12 */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,   FS,     FS,       FS,    FS,		FS}, // ASWR (ER)
	/* S13 */ {  FS,    FS,   FS,   FS,   FS,   FS,    FS,   FS,   FS,     FS,       FS,    FS,		FS}  // ASWR (ER)
};

/* Define accepting states types */
#define NOFS	0		/* not accepting state */
#define FSNR	1		/* accepting state with no retract */
#define FSWR	2		/* accepting state with retract */

/* TO_DO: Define list of acceptable states */
static uint stateType[NUM_STATES] = {
	NOFS, //00
	FSWR, //01
	NOFS, //02
	FSWR, //03
	NOFS, //04
	FSNR, //05
	NOFS, //06
	NOFS, //07
	NOFS, //08
	FSNR, //09
	NOFS, //10
	FSNR, //11
	FSNR, //12
	FSNR  //13
};

/*
----------------------------------
---------------
TO_DO: Adjust your functions'definitions
-------------------------------------------------
*/

/* Static (local) function  prototypes */
uint		startScanner(BufferPointer psc_buf);
static uint	nextClass(rune c);					/* character class function */
static uint	nextState(uint, rune);		/* state machine function */
void			printScannerData(ScannerData scData);
Token				tokenizer(void);

/*
-------------------------------------------------
Automata definitions
-------------------------------------------------
*/

/* TO_DO: Pointer to function (of one char * argument) returning Token */
typedef Token(*PTR_ACCFUN)(string lexeme);

/* Declare accepting states functions */
Token funcSL(string lexeme);
Token funcIL(string lexeme);
Token funcID(string lexeme);
Token funcCMT(string lexeme);
Token funcKEY(string lexeme);
Token funcErr(string lexeme);

/*
 * Accepting function (action) callback table (array) definition
 * If you do not want to use the typedef, the equvalent declaration is:
 */

 /* TO_DO: Define final state table */
static PTR_ACCFUN finalStateTable[NUM_STATES] = {
	NULL,       /* S0: NOAS */
	funcErr,    /* S1: FSWR */
	NULL,       /* S2: NOFS */
	funcKEY,     /* S3: FSNR */
	NULL,       /* S4: NOFS */
	funcID,     /* S5: FSNR */
	NULL,       /* S6: NOFS */
	funcIL,       /* S7: NOFS */
	NULL,       /* S8: NOFS */
	funcCMT,    /* S9: FSNR */
	NULL,       /* S10: NOFS */
	funcSL,    /* S11: FSNR */
	funcErr,    /* S12: FSNR */
	funcErr     /* S13: FSNR */
};


/*
-------------------------------------------------
Language keywords
-------------------------------------------------
*/

/* TO_DO: Define the number of Keywords from the Gojo language */
#define KWT_SIZE 18

/* TO_DO: Define the list of keywords for Gojo */
static string keywordTable[KWT_SIZE] = {
	"default",   /* KW00 */
	"func",      /* KW01 */
	"interface", /* KW02 */
	"case",      /* KW03 */
	"if",        /* KW04 */
	"for",       /* KW05 */
	"go",        /* KW06 */
	"map",       /* KW07 */
	"struct",    /* KW08 */
	"else",      /* KW09 */
	"type",      /* KW10 */
	"import",    /* KW11 */
	"goto",      /* KW12 */
	"package",   /* KW13 */
	"switch",    /* KW14 */
	"const",     /* KW15 */
	"continue",  /* KW16 */
	"return"     /* KW17 */
};


/* NEW SECTION: About indentation */

/*
 * Scanner attributes to be used (ex: including: intendation data
 */

#define INDENT '\t'  /* Tabulation */

 /* TO_DO: Should be used if no symbol table is implemented */
typedef struct languageAttributes {
	rune indentationCharType;
	uint indentationCurrentPos;
	/* TO_DO: Include any extra attribute to be used in your scanner (OPTIONAL and FREE) */
} LanguageAttributes;

/* Number of errors */
uint numScannerErrors;

/* Scanner data */
ScannerData scData;

#endif